DOMAIN = 'apsystems_ecur'
SOLAR_ICON = "mdi:solar-power"
FREQ_ICON = "mdi:sine-wave"
SIGNAL_ICON = "mdi:signal"
RELOAD_ICON = "mdi:reload"
CACHE_ICON = "mdi:cached"

